#include <iostream>
#include <cmath>

using namespace std;

int main() {
	
	  cout<<"\n\t----------------------------------------------------------------\n";
	  cout<<"\t                 SCIENTIFIC CALCULATOR                            \n";
      cout<<"\t------------------------------------------------------------------\n";
	  cout<<"\t 1.Addition(+)\t\t\t"          <<" 2.Subtraction(-)"<<endl;
	  cout<<"\t 3.Multiplication(*)\t\t"<<" 4.Division(/)"<<endl;
	  cout<<"\t 5.Exponent(^)\t\t\t"          <<" 6.Square(sqrt)"<<endl;
	  cout<<"\t 7.Logarithm(log)\t\t"       <<" 8.Trigonometry(sin,cos,tan)"<<endl;
	  cout<<"\t 9.Inverse Trig.(cot,cosec,sec)\t"<<" 10.Remainder(%)"<<endl;
	  cout<<"\t 11.Factorial(!)\t\t"<<" 12.Exit"<<endl;
	  
	  float a,b,pi=3.14159265;
	  int c,d,choice;
	  long factorial = 1.0;
	  
	  do{
	  	  cout<<"\n\tEnter the function you want to perform : ";
	  	  cin>>choice;
	  	  
	  	  switch(choice){
	  	  	        case 1:
	  	  	        	cout<<"\n\tEnter the first number: ";
	  	  	        	cin>>a;
	  	  	        	cout<<"\n\tEnter the second number: ";
	  	  	        	cin>>b;
	  	  	        	cout<<"\n\tResults = "<<a + b<<endl;
	  	  	        	break;
	  	  	        case 2:
						cout<<"\n\tEnter the first number: ";
	  	  	        	cin>>a;
	  	  	        	cout<<"\n\tEnter the second number: ";
	  	  	        	cin>>b;
	  	  	        	cout<<"\n\tResults = "<<a - b<<endl;
	  	  	        	break;	
	  	  	        case 3:
						cout<<"\n\tEnter the first number: ";
	  	  	        	cin>>a;
	  	  	        	cout<<"\n\tEnter the second number: ";
	  	  	        	cin>>b;
	  	  	        	cout<<"\n\tResults = "<<a * b<<endl;
	  	  	        	break;
				    case 4:
				    	cout<<"\n\tEnter the first number: ";
	  	  	        	cin>>a;
	  	  	        	cout<<"\n\tEnter the second number: ";
	  	  	        	cin>>b;
	  	  	        	cout<<"\n\tResults = "<<a / b<<endl;
	  	  	        	break;
	  	  	        case 5:
						cout<<"\n\tEnter the  number: ";
	  	  	        	cin>>a;
	  	  	        	cout<<"\n\tEnter the exponent: ";
	  	  	        	cin>>b;
	  	  	        	cout<<"\n\tResults = "<<pow(a,b)<<endl;
	  	  	        	break;	
					case 6:
					    cout<<"\n\tEnter first number: ";
						cin>>a;
						cout<<"\n\tResults =  "<<sqrt(a)<<endl;
						cout<<"\n\tEnter second number: ";
						cin>>b;
						cout<<"\n\tResults =  "<<sqrt(b)<<endl;
						
						break;
					case 7:
					    cout<<"\n\tEnter first number: ";
						cin>>a;
						cout<<"\n\tResults = "<<log2(a)<<endl;
						cout<<"\n\tEnter second number: ";
						cin>>b;
						cout<<"\n\tResults = "<<log10(b)<<endl;
						cout<<"\n\tEnter the number: ";
						cin>>b;
						cout<<"\n\tResults = "<<log(b)<<endl;
						break;	
					case 8:
					    cout<<"\n\tEnter the number: ";
						cin>>a;
						cout<<"\n\tResults of sine() = "<<sin(a)<<endl;
						cout<<"\n\tEnter the number: ";
						cin>>a;
						cout<<"\n\tResults of cos() = "<<cos(a)<<endl;
						cout<<"\n\tEnter the number: ";
						cin>>a;
						cout<<"\n\tResults of tan() = "<<tan(a)<<endl;
						break;
					case 9:
					    cout<<"\n\tEnter the number: ";
						cin>>a;
						cout<<"\n\tResults = "<<asin(a)*180.0/pi<<endl;
						cout<<"\n\tEnter the number: ";
						cin>>a;
						cout<<"\n\tResults = "<<acos(a)*180.0/pi<<endl;	
						cout<<"\n\tEnter the number: ";
						cin>>a;
						cout<<"\n\tResults = "<<atan(a)*180.0/pi<<endl;	
						break;
					case 10:
					    cout<<"\n\t\Enter the first number: ";
						  cin>>c;
						cout<<"\n\tEnter the second number: ";
						 cin>>d;
						cout<<"\n\tResults = "<<c % d<<endl;
						break;
					case 11:
						cout<<"\n\tEnter the number: ";
						cin>>a;
						    for(int i=1;i<=a;i++){
						    	factorial *= i;	
							}
						cout<<"\n\tResults of factorial "<<a<<" = "<<factorial<<endl;			
					    break;
					case 12:
					    cout<<"\n\tCalculator Off";
						break;
						       
					default:
					    cout<<"\n\tWrong choice entered"<<endl;
						break;										
								
			}
	  }while(choice != 12);
	  	
	
	
	
	return 0;
}
